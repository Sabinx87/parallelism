import os, time, csv
import torch, torch.nn as nn, torch.distributed as dist
from torch.nn.parallel import DistributedDataParallel as DDP
from torch.profiler import profile, ProfilerActivity
from torchvision import models
from torchvision.models.vision_transformer import VisionTransformer

NUM_CLASSES = 200

def build_model(name, res):
    if name == 'resnet18': return models.resnet18(weights=None, num_classes=NUM_CLASSES)
    if name == 'resnet34': return models.resnet34(weights=None, num_classes=NUM_CLASSES)
    if name == 'resnet50': return models.resnet50(weights=None, num_classes=NUM_CLASSES)
    if name == 'vitbase':  return models.vit_b_16(weights=None, image_size=res,
                                                  num_classes=NUM_CLASSES)
    if name == 'vittiny':  return VisionTransformer(image_size=res, patch_size=16,
                               num_layers=12, num_heads=3, hidden_dim=192,
                               mlp_dim=768, num_classes=NUM_CLASSES)
    raise ValueError(name)

def make_batch(bs, device, res, seed=0):
    g = torch.Generator().manual_seed(seed)
    x = torch.randn(bs, 3, res, res, generator=g).to(device)
    y = torch.randint(0, NUM_CLASSES, (bs,), generator=g).to(device)
    return x, y

def dp_worker(rank, world, model_name, global_bs, res, repeat, warmup, measured,
              path, port, warm_sec):
    os.environ['MASTER_ADDR'], os.environ['MASTER_PORT'] = 'localhost', str(port)
    dist.init_process_group('nccl', rank=rank, world_size=world)
    torch.cuda.set_device(rank)
    dev, bs = f'cuda:{rank}', global_bs // world          # per-GPU batch = B / 2

    model = DDP(build_model(model_name, res).to(dev), device_ids=[rank])
    opt = torch.optim.SGD(model.parameters(), lr=0.01, momentum=0.9)
    crit = nn.CrossEntropyLoss()
    x, y = make_batch(bs, dev, res, seed=rank)

    def nosync():
        opt.zero_grad(set_to_none=True)
        with model.no_sync():
            crit(model(x), y).backward()
    def synced():
        opt.zero_grad(set_to_none=True)
        crit(model(x), y).backward()
    def timed(fn):
        torch.cuda.synchronize(dev); t = time.perf_counter()
        fn(); torch.cuda.synchronize(dev)
        return (time.perf_counter() - t) * 1e3

    # warm up for at least `warmup` steps AND `warm_sec` seconds; GPU 0 decides when to stop
    t_w, n = time.perf_counter(), 0
    while True:
        nosync(); synced(); opt.step(); n += 1
        done = torch.tensor([float(n >= warmup and time.perf_counter() - t_w >= warm_sec)],
                            device=dev)
        dist.broadcast(done, src=0)
        if done.item(): break
    torch.cuda.synchronize(dev)
    torch.cuda.reset_peak_memory_stats(dev)

    rows = []
    for i in range(measured):
        if i % 2 == 0:
            t_ns = timed(nosync); t_s = timed(synced); t_o = timed(opt.step)
        else:
            t_s = timed(synced); t_o = timed(opt.step); t_ns = timed(nosync)
        rows.append([model_name, 'dp', global_bs, bs, res, repeat, i, i % 2,
                     round(t_ns, 3), round(t_s, 3), round(t_o, 3),
                     round(t_s + t_o, 3), round(t_s - t_ns, 3)])

    with profile(activities=[ProfilerActivity.CUDA]) as prof:
        for _ in range(20):
            synced(); opt.step()
        torch.cuda.synchronize(dev)
    dt = lambda e: getattr(e, 'device_time_total', 0) or getattr(e, 'cuda_time_total', 0)
    nccl = [e for e in prof.key_averages()
            if e.key.lower().startswith('nccl') and 'kernel' in e.key.lower()]
    nccl_ms = sum(dt(e) for e in nccl) / 1e3 / 20

    if rank == 0:
        peak = torch.cuda.max_memory_allocated(dev) / 2**20
        tmp = path + '.tmp'
        with open(tmp, 'w', newline='') as fh:
            w = csv.writer(fh)
            w.writerow(['model', 'config', 'batch', 'per_gpu_batch', 'res', 'repeat', 'step',
                        'order', 'nosync_ms', 'sync_ms', 'opt_ms', 'step_ms',
                        'exposed_comm_ms', 'nccl_ms', 'peak_mem_mb'])
            for r in rows: w.writerow(r + [round(nccl_ms, 3), round(peak, 1)])
        os.replace(tmp, path)
        med = lambda k: sorted(r[k] for r in rows)[measured // 2]
        print(f"{os.path.basename(path)[:-4]}: step {med(11):.1f} ms | "
              f"exposed {med(12):.1f} ms | nccl {nccl_ms:.1f} ms | warm-up {n} steps")

    dist.destroy_process_group()

def allreduce_worker(rank, world, sizes_mb, iters, path, port):
    os.environ['NCCL_DEBUG'], os.environ['NCCL_DEBUG_SUBSYS'] = 'INFO', 'INIT'   # prints transport
    os.environ['MASTER_ADDR'], os.environ['MASTER_PORT'] = 'localhost', str(port)
    dist.init_process_group('nccl', rank=rank, world_size=world)
    torch.cuda.set_device(rank)
    dev = f'cuda:{rank}'
    rows = []
    for mb in sizes_mb:
        t = torch.ones(int(mb * 2**20 / 4), device=dev)
        for _ in range(5): dist.all_reduce(t)
        torch.cuda.synchronize(dev)
        times = []
        for _ in range(iters):
            dist.barrier(device_ids=[rank]); torch.cuda.synchronize(dev)   # start together
            s = time.perf_counter()
            dist.all_reduce(t); torch.cuda.synchronize(dev)
            times.append((time.perf_counter() - s) * 1e3)
        med = sorted(times)[iters // 2]
        rows.append([round(mb, 2), round(med, 3), round(mb / 1024 / (med / 1e3), 3)])
    if rank == 0:
        with open(path, 'w', newline='') as fh:
            w = csv.writer(fh); w.writerow(['size_mb', 'median_ms', 'gb_per_s']); w.writerows(rows)
        for r in rows: print(f"all-reduce {r[0]:8.2f} MB: {r[1]:8.3f} ms  ->  {r[2]:.2f} GB/s")
    dist.destroy_process_group()
